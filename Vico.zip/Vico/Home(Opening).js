setTimeout(function() {
    window.location.href = "Home(Select Language).html";
}, 3000);